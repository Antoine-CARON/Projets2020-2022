//les 2 / indiquent une note
var Window;  
 
// Function that open the new Window  
 
function windowOpen() 
{  Window = window.open(  "https://fr.wikipedia.org/wiki/Netflix");   }  
 
// function that Closes the open Window  
function windowClose() 
{  Window.close("https://fr.wikipedia.org/wiki/Netflix");
  alert("La page wikipedia est fermée !")  }  
//questionnaire partie js  function valider1() {    if (document.getElementById('serie1b').checked)
	//  {    alert('Bravo !!!')    }    
  //else {    alert('Votre réponse est incorrecte...')    }   } 
 
 // function valider2()
 // {    if (document.getElementById('serie2a').checked)
//	  {    alert('Bravo !!!')    }    
 // else {    alert('Votre réponse est incorrecte...')    }   } 
//questionnaire partie html:<p> Qui a découvert la radioactivité ? </p>  <div>  
//	<input name="serie1" id="serie1a" type="radio">Newton<br>
	//<input name="serie1" id="serie1b" type="radio"> Becquerel<br> 
	//<input name="serie1" id="serie1c" type="radio">Einstein<br>  
	//</div>  <input type="button" onClick="valider1()" value="Valider"> 
 
 //<p> Qui a découvert l’Amérique ? </p> 
// <div>   <input name="serie2" id="serie2a" type="radio">Christophe Colomb<br>  
// <input name="serie2" id="serie2b" type="radio"> Becquerel<br>   
 //<input name="serie2" id="serie2c" type="radio">Einstein<br>  </div>  
 //<input type="button" onClick="valider2()" value="Valider"> 


  
function titrepresentation(obj)  
 {//traitement
//redirection
} 
function titrehistoire(obj)  
 {//traitement
//redirection
} 
function titreseries(obj)  
 {//traitement
//redirection
} 
function titrefilms(obj)  
 {//traitement
//redirection
} 
function titreconclu(obj)  
 {//traitement
//redirection
 }
function precedent1(obj)  
 {//traitement
//redirection
} 
function suivant1(obj)  
 {//traitement
//redirection
} 
function suivant2(obj)  
 {//traitement
//redirection
} 
function precedent2(obj)  
 {//traitement
//redirection
} 
function suivant3(obj)  
 {//traitement
//redirection
} 
function precedent3(obj)  
 {//traitement
//redirection
} 
function precedent4(obj)  
 {//traitement
//redirection
} 
function infos(obj)  
 {//traitement
//redirection
} 
function changewitcher(obj)  
{// getElementById methode peremet de specifier element par id
 //setAttributettribute remplace l image par autredont le nom est ...
	 var x = document.getElementById("witcher1");
 //var x =element.getElementsByTagName("img") item(0)
 var v = x.getAttribute("src");
 if(v == "Images/witcher2.jpg")
 {
	 // pour verifier fonctionnement enlever les  aux "alert"
	 //alert("Image Witcher !"); 
	 x.setAttribute("src","Images/witcher.png");
 }
 else
 {
	 //alert("image witcher ko !");
 x.setAttribute("src","Images/witcher2.jpg");
 }
} 
